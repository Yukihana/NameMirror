﻿using System;
using System.ComponentModel;

namespace CopyNamer.Models
{
    internal class LogEntryModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        // Business Data
        private readonly DateTime timeStamp;
        private readonly string message;
        private readonly LogVerboseLevel verboseLevel;
        private readonly string source;
        private readonly string details;
        private readonly string linkText;
        private readonly string linkAction; // if link is uri, open directory. else send to main, which will handle task delegation from there (hook to event)
        
        // Bindable
        public DateTime TimeStamp => timeStamp;
        public string Message => message;
        public LogVerboseLevel LogVerboseLevel => verboseLevel;
        public string Source => source;
        public string Details => details;
        public string LinkText => linkText;
        public string LinkAction => linkAction;

        // Ctor
        public LogEntryModel(
            string message,
            LogVerboseLevel verboseLevel = LogVerboseLevel.Information,
            string source = "",
            string details = "",
            string linkText = "",
            string linkAction = "")
        {
            timeStamp = DateTime.Now;
            this.message = message;
            this.verboseLevel = verboseLevel;
            this.source = source;
            this.details = details;
            this.linkText = linkText;
            this.linkAction = linkAction;
        }
    }

    public enum LogVerboseLevel : byte
    {
        Debug = 0,
        Noise = 1,
        Details = 2,
        Information = 3,
        Warning = 4,
        Error = 5,
    }
}
