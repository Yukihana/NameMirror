﻿using CopyNamer.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyNamer.Logic
{
    internal class MainLogic : INotifyPropertyChanged
    {
        // Business Data
        #region CopyModels
        private readonly ObservableCollection<CopyNamingModel> copyModels = new();
        public ObservableCollection<CopyNamingModel> CopyModels => copyModels;
        #endregion

        #region SelectedModels
        private readonly ObservableCollection<CopyNamingModel> selectedModels = new();
        public ObservableCollection<CopyNamingModel> SelectedModels => selectedModels;
        #endregion

        #region LogEntries
        private readonly ObservableCollection<LogEntryModel> logEntries = new();
        public ObservableCollection<LogEntryModel> LogEntries => logEntries;
        #endregion

        // Presentation Data
        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler? PropertyChanged;
        #endregion

        #region Log Capacity & Stepping
        // Log Capacity Config
        public static readonly int[] LogCaps = new int[] { 0, 10, 50, 100, 200, 500, 1000, 2000, 5000, 9999 };
        private static readonly int DefaultStepIndex = 3;
        public static int GetLogCapacity(int stepping) => (stepping > 0 && stepping < LogCaps.Length) ? LogCaps[stepping] : LogCaps[DefaultStepIndex];
        // Property : StepIndex
        private double stepIndex = -1;
        public double StepIndex
        {
            get
            {
                if(stepIndex == -1)
                {
                    stepIndex = DefaultStepIndex;
                }
                return stepIndex;
            }
            set
            {
                stepIndex = (value >= 0 && value < LogCaps.Length) ? value : DefaultStepIndex;
                PropertyChanged?.Invoke(this, new(nameof(StepIndex)));
                PropertyChanged?.Invoke(this, new(nameof(LogCapacity)));
            }
        }
        // Property : LogCapacity
        public int LogCapacity => GetLogCapacity((int)stepIndex);
        // Properties : Derived
        public static double StepIndexMinimum => 0;
        public static double StepIndexMaximum => LogCaps.Length;
        #endregion


        #region Tasks
        // Add
        internal void AddTasks(string[] fileNames)
        {
            int n = 0, e = 0, c = 0;
            string s;
            foreach (string file in fileNames)
            {
                if (!File.Exists(file))
                {
                    LogAdd("Unable to add task (File does not exist): " + Path.GetFullPath(file));
                    e++;
                    continue;
                }

                s = Path.GetFullPath(file);
                if (CopyModels.Any(x => x.OriginalFullPath == s && x.Status != StatusStates.Done))
                {
                    LogAdd("Unable to add task (Already on the list): " + Path.GetFullPath(file));
                    c++;
                    continue;
                }

                CopyModels.Add(new CopyNamingModel(s));
                n++;
            }

            LogAdd(
                $"Added {n} of {fileNames.Length} files to the task list."
                + (e > 0 ? $" {e} files don't exist." : "")
                + (c > 0 ? $" {c} files are already pending on the task list." : "")
            );
        }
        
        #endregion



        // References
        internal void AddReferences(string[] fileNames)
        {
            // Prepare
            // (Exists validation is not required because only the filename is needed)
            // (Uniqueness validation condition: only for same target folder. Implementation pending)
            var unreferenced = CopyModels.Where(x => x.Status == StatusStates.NoRef).ToArray();
            var uncount = unreferenced.Length;
            var fcount = fileNames.Length;
            int n = 0;

            for (int i = 0; i < fcount; i++)
            {
                if (i >= uncount)
                {
                    break;
                }
                try
                {
                    unreferenced[i].ReferenceFullPath = Path.GetFullPath(fileNames[i]);
                    n++;
                }
                catch (Exception e)
                {
                    LogAdd($"Error - {e.Source}: {e.Message}");
                }
            }

            // Log count mismatch message
            LogAdd($"Added {n} of {fcount} name references."
                + (uncount > fcount ? $" {uncount - fcount} unreferenced tasks remaining. Add more reference files to continue from the next unreferenced task." : "")
                + (uncount < fcount ? $" {fcount - uncount} excess references files were ignored. If this was not intended, clear reference(s) and try again." : "")
                );
        }


        // Rename
        internal void RenameAll()
        {
            int n = 0, e = 0;
            foreach (CopyNamingModel model in CopyModels.Where(x => x.Status == StatusStates.Ready))
            {
                if (model.Rename())
                {
                    n++;
                    LogAdd($"Renaming successful: \"{model.OriginalFullPath}\" => \"{model.NewFullPath}\"", LogVerboseLevel.Details);
                }
                else
                {
                    e++;
                    LogAdd($"Renaming failed: \"{model.OriginalFullPath}\" => \"{model.NewFullPath}\".\nReason:\n{model.StatusMessage}", LogVerboseLevel.Error);
                }
            }

            LogAdd($"Files renamed: {n}. There "
                + (e == 1 ? "was" : "were")
                + $" {(e == 0 ? "no" : e)} errors.");
        }


        // Purge
        internal void RemoveTasks()
        {
            int n = 0;

            // Create localized shallow copy to prevent cyclic stack overflow
            List<CopyNamingModel> ToRemove = new(SelectedModels);

            // Remove from master collection
            foreach (var task in ToRemove)
            {
                if (CopyModels.Contains(task))
                {
                    CopyModels.Remove(task);
                    n++;
                }
            }

            LogAdd($"Removed {n} tasks.");
        }

        // Move entirety of log into a component
        public void ExternalLogAdd(string message, LogVerboseLevel level = LogVerboseLevel.Information) => LogAdd(message, level);
        // Log
        void LogAdd(string message, LogVerboseLevel level = LogVerboseLevel.Information)
        {
            LogEntries.Add(new(message, level));
            LogPurge();
        }
        void LogPurge()
        {
            // Add property bind for max count

            // For count: excess, iterate backwards from n-1 and remove entries
        }

        // Support, View assist
        internal int GetUnreferencedCount() => CopyModels.Where(x => x.Status == StatusStates.NoRef).Count();
        
    }
}
