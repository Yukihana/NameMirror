﻿using CopyNamer.Logic;
using CopyNamer.Models;
using Microsoft.Win32;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Ribbon;

namespace CopyNamer.Windows
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : RibbonWindow
    {
        readonly MainLogic MyLogic = new();
        string LastTaskPath = string.Empty;
        string LastRefPath = string.Empty;

        public MainWindow()
        {
            InitializeComponent();
            DataContext = MyLogic;
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            MyLogic.ExternalLogAdd("Program loaded.");
            MyLogic.ExternalLogAdd("How-To basics:\n1. Add tasks (original files),\n2. Add references (files to copy names from),\n3. Rename", LogVerboseLevel.Noise);
        }

        private void FileList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            MyLogic.SelectedModels.Clear();
            foreach (var n in FileList.SelectedItems)
            {
                MyLogic.SelectedModels.Add((CopyNamingModel)n);
            }
        }


        // Move all this junk to commands
        private void AddOrigFiles_Click(object sender, RoutedEventArgs e)
        {
            // Prepare
            OpenFileDialog openFileDialog = new()
            {
                InitialDirectory = LastTaskPath,
                Title = "Add files to rename...",
                Filter = "Image files (*.jpg, *.jpeg, *.bmp, *.png, *.gif)|*.JPG;*.JPEG;*.BMP;*.PNG;*.GIF|Document files (*.docx, *.doc, *.pdf, *.rtf)|*.DOCX;*.DOC;*.PDF;*.RTF|All files (*.*)|*.*",
                Multiselect = true,
                CheckFileExists = true,
                CheckPathExists = true,
                ValidateNames = true,
            };

            //Query User
            if(openFileDialog.ShowDialog() == true)
            {
                // Business logic delegation
                MyLogic.AddTasks(openFileDialog.FileNames);

                // Save last path
                if(openFileDialog.FileNames.Length > 0)
                    LastTaskPath = Path.GetDirectoryName(openFileDialog.FileNames[0]) ?? string.Empty;
            }
        }

        private void AddRefFiles_Click(object sender, RoutedEventArgs e)
        {
            // Check status
            var uncount = MyLogic.GetUnreferencedCount();
            if (uncount == 0)
            {
                MessageBox.Show(
                    "There are no unreferenced tasks. To add more references,"
                    + "\n- Add more files to the task list first"
                    + "\n  Or"
                    + "\n- Clear references from pending tasks",
                    "Nothing to reference",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                return;
            }

            // Prepare
            OpenFileDialog openFileDialog = new()
            {
                InitialDirectory = LastRefPath,
                Title = "Add files to copy names from...",
                Filter = "Image files (*.jpg, *.jpeg, *.bmp, *.png, *.gif)|*.JPG;*.JPEG;*.BMP;*.PNG;*.GIF|Document files (*.docx, *.doc, *.pdf, *.rtf)|*.DOCX;*.DOC;*.PDF;*.RTF|All files (*.*)|*.*",
                Multiselect = true,
                CheckFileExists = true,
                CheckPathExists = true,
                ValidateNames = true,
            };

            // Query user
            if (openFileDialog.ShowDialog() == true)
            {
                // Business logic delegation
                MyLogic.AddReferences(openFileDialog.FileNames);

                // Save last path
                if (openFileDialog.FileNames.Length > 0)
                    LastRefPath = Path.GetDirectoryName(openFileDialog.FileNames[0]) ?? string.Empty;
            }
        }

        private void Rename_Click(object sender, RoutedEventArgs e) => MyLogic.RenameAll();

        private void RemoveTask_Click(object sender, RoutedEventArgs e)
        {
            // Adding deletion confirmation to prevent accidental deletion of tasks, that may cause major hindrance to the workflow
            if(MessageBox.Show("Delete selected task(s)?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Asterisk, MessageBoxResult.Yes) == MessageBoxResult.Yes)
            {
                MyLogic.RemoveTasks();
            }
        }

        

        
    }
}
