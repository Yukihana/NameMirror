﻿using CopyNamerLib.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace CopyNamerLib.Commands.ReferencedNaming
{
    internal class TaskClearCommand : ICommand
    {
        private ReferencedNamingLogic MyLogic;
        public event EventHandler? CanExecuteChanged;

        public TaskClearCommand(ReferencedNamingLogic mainLogic) => MyLogic = mainLogic;

        public bool CanExecute(object? parameter)
        {
            throw new NotImplementedException();
        }

        public void Execute(object? parameter)
        {
            throw new NotImplementedException();
        }
    }
}
