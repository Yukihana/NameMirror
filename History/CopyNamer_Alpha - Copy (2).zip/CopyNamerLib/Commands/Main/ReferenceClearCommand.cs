﻿namespace CopyNamerLib.Commands.ReferencedNaming
{
    internal class ReferenceClearCommand
    {
    }
}
