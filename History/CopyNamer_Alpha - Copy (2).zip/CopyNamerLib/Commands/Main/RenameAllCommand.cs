﻿using CopyNamerLib.Logic;

namespace CopyNamerLib.Commands.ReferencedNaming
{
    public class RenameAllCommand : CommandBase
    {
        public RenameAllCommand(ReferencedNamingLogic logic) : base(logic) { }
        public override bool CanExecute(object? parameter) => Logic.CanRenameAll();
        public override void Execute(object? parameter) => Logic.RenameAll();
    }
}