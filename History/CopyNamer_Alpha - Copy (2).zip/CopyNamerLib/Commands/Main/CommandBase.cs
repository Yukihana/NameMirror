﻿namespace CopyNamerLib.Commands.ReferencedNaming
{
    public abstract class CommandBase : System.Windows.Input.ICommand
    {
        // Data
        public event EventHandler? CanExecuteChanged;
        protected Logic.ReferencedNamingLogic Logic;

        // Ctor
        public CommandBase(Logic.ReferencedNamingLogic logic) => Logic = logic;

        // Methods
        public abstract bool CanExecute(object? parameter);
        public abstract void Execute(object? parameter);
    }
}