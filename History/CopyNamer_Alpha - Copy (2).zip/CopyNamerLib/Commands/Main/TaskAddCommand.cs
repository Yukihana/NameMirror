﻿using CopyNamerLib.Logic;

namespace CopyNamerLib.Commands.ReferencedNaming
{
    public class TaskAddCommand : CommandBase
    {
        public TaskAddCommand(ReferencedNamingLogic logic) : base(logic) { }
        public override bool CanExecute(object? parameter) => Logic.CanAddTasks();
        public override void Execute(object? parameter) => Logic.AddTasks();
    }
}