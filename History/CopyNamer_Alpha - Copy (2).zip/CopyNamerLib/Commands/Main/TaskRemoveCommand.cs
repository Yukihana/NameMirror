﻿using CopyNamerLib.Logic;

namespace CopyNamerLib.Commands.ReferencedNaming
{
    public class TaskRemoveCommand : CommandBase
    {
        public TaskRemoveCommand(ReferencedNamingLogic logic) : base(logic) { }
        public override bool CanExecute(object? parameter) => Logic.CanRemoveTasks();
        public override void Execute(object? parameter) => Logic.RemoveTasks();
    }
}