﻿using CopyNamerLib.Logic;

namespace CopyNamerLib.Commands.ReferencedNaming
{
    public class ReferenceAddCommand : CommandBase
    {
        public ReferenceAddCommand(ReferencedNamingLogic logic) : base(logic) { }
        public override bool CanExecute(object? parameter) => Logic.CanAddReferences();
        public override void Execute(object? parameter) => Logic.AddReferences();
    }
}