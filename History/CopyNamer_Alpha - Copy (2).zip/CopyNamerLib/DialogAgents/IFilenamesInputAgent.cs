﻿namespace CopyNamerLib.DialogAgents
{
    public interface IFilenamesInputAgent
    {
        public string[]? GetFiles(string message);
    }
}