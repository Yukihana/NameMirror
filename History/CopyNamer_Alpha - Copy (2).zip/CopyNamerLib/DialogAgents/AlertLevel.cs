﻿namespace CopyNamerLib.DialogAgents
{
    public enum AlertLevel : byte
    {
        Information = 0,
        Query = 1,
        Warning = 2,
        Error = 3,
    }
}
