﻿namespace CopyNamerLib.DialogAgents
{
    public interface IAlertDialogAgent
    {
        public void ShowDialog(
            string message,
            string title = "Alert",
            AlertLevel level = AlertLevel.Information
            );
    }
}