﻿namespace CopyNamerLib.DialogAgents
{
    public enum AlertImage : byte
    {
        None = 0,
        Default = 1,
        Custom = 2,
    }
}