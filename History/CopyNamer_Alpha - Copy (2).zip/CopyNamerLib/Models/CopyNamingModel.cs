﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyNamerLib.Models
{
    public class CopyNamingModel : INotifyPropertyChanged
    {
        private string originalFullPath = string.Empty;
        private string referenceFullPath = string.Empty;
        private string newFilename = string.Empty;

        public event PropertyChangedEventHandler? PropertyChanged;

        // Core Data
        public string OriginalFullPath
        {
            get => originalFullPath;
            private set
            {
                originalFullPath = value;
                PropertyChanged?.Invoke(this, new(nameof(OriginalFullPath)));
                // Derived
                PropertyChanged?.Invoke(this, new(nameof(OriginalFilename)));
                PropertyChanged?.Invoke(this, new(nameof(OriginalFilenameWithoutExtension)));
                PropertyChanged?.Invoke(this, new(nameof(OriginalFileExtension)));
                PropertyChanged?.Invoke(this, new(nameof(OriginalDirectory)));
                // Status
                EvaluateTaskStatus();
            }
        }
        public string ReferenceFullPath
        {
            get => referenceFullPath;
            set
            {
                // Deny if task has already completed
                if (Status == StatusStates.Done)
                {
                    return;
                }


                referenceFullPath = value;
                PropertyChanged?.Invoke(this, new(nameof(ReferenceFullPath)));
                // Derived
                PropertyChanged?.Invoke(this, new(nameof(ReferenceFilename)));
                PropertyChanged?.Invoke(this, new(nameof(ReferenceFilenameWithoutExtension)));
                PropertyChanged?.Invoke(this, new(nameof(ReferenceDirectory)));
                // Status
                EvaluateTaskStatus();
                GenerateNewFilename();
            }
        }
        // Original: Derived
        public string OriginalFilename => Path.GetFileName(OriginalFullPath);
        public string OriginalFilenameWithoutExtension => Path.GetFileNameWithoutExtension(OriginalFullPath);
        public string OriginalFileExtension => Path.GetExtension(OriginalFullPath);
        public string OriginalDirectory => Path.GetDirectoryName(OriginalFullPath) ?? string.Empty;

        // Reference: Derived
        public string ReferenceFilename => Path.GetFileName(ReferenceFullPath);
        public string ReferenceFilenameWithoutExtension => Path.GetFileNameWithoutExtension(ReferenceFullPath);
        public string ReferenceDirectory => Path.GetDirectoryName(ReferenceFullPath) ?? string.Empty;

        // New (Has SetValue for editability)
        public string NewFilename
        {
            get => newFilename;
            set
            {
                newFilename = value;
                // Update
                PropertyChanged?.Invoke(this, new(nameof(NewFilename)));
                PropertyChanged?.Invoke(this, new(nameof(NewFullPath)));
            }
        }
        public string NewFullPath => Path.Combine(OriginalDirectory, NewFilename);

        // Status
        private StatusStates status = StatusStates.NoTask;
        public StatusStates Status
        {
            get => status;
            private set
            {
                status = value;
                PropertyChanged?.Invoke(this, new(nameof(Status)));
            }
        }
        public string StatusMessage { get; private set; } = string.Empty;

        // Ctor
        public CopyNamingModel(string OriginalFullPath) => this.OriginalFullPath = Path.GetFullPath(OriginalFullPath);

        // Update
        public void GenerateNewFilename() => NewFilename = ReferenceFilenameWithoutExtension + OriginalFileExtension;


        // Rename
        public bool Rename()
        {
            bool result = true;
            try
            {
                File.Move(OriginalFullPath, NewFullPath);
                Status = StatusStates.Done;
            }
            catch (Exception ex)
            {
                StatusMessage = ex.Source + ": " + ex.Message;
                Status = StatusStates.Failed;
                result = false;
            }
            return result;
        }

        // Task Eval. Note: file-eval to be used only for Error Evaluation
        void EvaluateTaskStatus()
        {
            // Ditch if task is already completed
            if (Status == StatusStates.Done)
            {
                return;
            }

            // Stage 1 of 2: Task validation
            if (string.IsNullOrEmpty(OriginalFullPath))
            {
                Status = StatusStates.NoTask;
                return;
            }
            Status = StatusStates.NoRef;

            // Stage 2 of 2: Reference validation
            if (!string.IsNullOrEmpty(ReferenceFullPath))
            {
                Status = StatusStates.Ready;
            }
        }
    }

    public enum StatusStates : byte
    {
        NoTask = 0,
        NoRef = 1,
        Ready = 2,
        Done = 3,
        Failed = 4,
    }
}
