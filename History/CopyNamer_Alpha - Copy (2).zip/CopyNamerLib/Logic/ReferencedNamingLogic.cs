﻿using CopyNamerLib.Commands.ReferencedNaming;
using CopyNamerLib.DialogAgents;
using CopyNamerLib.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyNamerLib.Logic
{
    public class ReferencedNamingLogic : INotifyPropertyChanged
    {
        // Interface and Updates
        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler? PropertyChanged;
        #endregion

        #region Interface Agents
        public IFilenamesInputAgent? TasksInputAgent { get; set; } = null;
        public IFilenamesInputAgent? ReferencesInputAgent { get; set; } = null;
        public IAlertDialogAgent? AlertDialogAgent { get; set; } = null;
        public IQueryDialogAgent? QueryDialogAgent { get; set; } = null;
        #endregion


        // Business Data
        #region CopyModels
        private readonly ObservableCollection<CopyNamingModel> copyModels = new();
        public ObservableCollection<CopyNamingModel> CopyModels => copyModels;
        #endregion

        #region LogEntries
        private readonly ObservableCollection<LogEntryModel> logEntries = new();
        public ObservableCollection<LogEntryModel> LogEntries => logEntries;
        #endregion


        // Presentation Data
        #region SelectedModels
        private readonly ObservableCollection<CopyNamingModel> selectedModels = new();
        public ObservableCollection<CopyNamingModel> SelectedModels => selectedModels;
        #endregion

        #region Log Capacity & Stepping
        // Log Capacity Config
        public static readonly int[] LogCaps = new int[] { 0, 10, 50, 100, 200, 500, 1000, 2000, 5000, 9999 };
        private static readonly int DefaultStepIndex = 3;
        public static int GetLogCapacity(int stepping) => (stepping > 0 && stepping < LogCaps.Length) ? LogCaps[stepping] : LogCaps[DefaultStepIndex];
        // Property : StepIndex
        private double stepIndex = -1;
        public double StepIndex
        {
            get
            {
                if (stepIndex == -1)
                {
                    stepIndex = DefaultStepIndex;
                }
                return stepIndex;
            }
            set
            {
                stepIndex = (value >= 0 && value < LogCaps.Length) ? value : DefaultStepIndex;
                PropertyChanged?.Invoke(this, new(nameof(StepIndex)));
                PropertyChanged?.Invoke(this, new(nameof(LogCapacity)));
            }
        }
        // Property : LogCapacity
        public int LogCapacity => GetLogCapacity((int)stepIndex);
        // Properties : Derived
        public static double StepIndexMinimum => 0;
        public static double StepIndexMaximum => LogCaps.Length;
        #endregion

        
        // Commands : Tasks
        #region Command : Add
        private readonly TaskAddCommand taskAddCommand;
        public TaskAddCommand TaskAddCommand => taskAddCommand;
        public bool CanAddTasks() => true;
        public void AddTasks()
        {
            // If an agent has not been assigned, return
            if(TasksInputAgent == null)
            {
                LogAdd($"{GetType().FullName} Internal error: Unassigned interface agent - {nameof(TasksInputAgent)}", LogVerboseLevel.Error);
                return;
            }

            // If null, user has cancelled adding tasks
            string[]? fileNames = TasksInputAgent.GetFiles("Add files to rename...");
            if(fileNames == null)
            {
                LogAdd("Cancelled adding tasks", LogVerboseLevel.Debug);
                return;
            }

            // Add
            int n = 0, e = 0, c = 0;
            string s;
            foreach (string file in fileNames)
            {
                if (!File.Exists(file))
                {
                    LogAdd("Unable to add task (File does not exist): " + Path.GetFullPath(file));
                    e++;
                    continue;
                }

                s = Path.GetFullPath(file);
                if (CopyModels.Any(x => x.OriginalFullPath == s && x.Status != StatusStates.Done))
                {
                    LogAdd("Unable to add task (Already on the list): " + Path.GetFullPath(file));
                    c++;
                    continue;
                }

                CopyModels.Add(new CopyNamingModel(s));
                n++;
            }

            // Log operation
            LogAdd(
                $"Added {n} of {fileNames.Length} files to the task list."
                + (e > 0 ? $" {e} files don't exist." : "")
                + (c > 0 ? $" {c} files are already pending on the task list." : "")
            );
        }
        #endregion

        #region Commands : Remove
        private readonly TaskRemoveCommand taskRemoveCommand;
        public TaskRemoveCommand TaskRemoveCommand => taskRemoveCommand;
        public bool CanRemoveTasks() => true;
        public void RemoveTasks()
        {
            // If an agent has not been assigned, return
            if (QueryDialogAgent == null)
            {
                LogAdd($"{GetType().FullName} Internal error: Unassigned interface agent - {nameof(QueryDialogAgent)}", LogVerboseLevel.Error);
                return;
            }

            // Adding confirmation to prevent accidents
            if (QueryDialogAgent.ShowDialog("Delete selected task(s)?", "Confirmation", new string[] { "Yes", "No" }, AlertLevel.Query) != 0)
            {
                return;
            }

            int n = 0;

            // Create localized shallow copy to prevent cyclic stack overflow
            List<CopyNamingModel> ToRemove = new(SelectedModels);

            // Remove from master collection
            foreach (var task in ToRemove)
            {
                if (CopyModels.Contains(task))
                {
                    CopyModels.Remove(task);
                    n++;
                }
            }

            LogAdd($"Removed {n} tasks.");
        }
        #endregion


        // Commands : References
        #region Command : Add References
        private readonly ReferenceAddCommand addReferencesCommand;
        public ReferenceAddCommand AddReferencesCommand => addReferencesCommand;
        public bool CanAddReferences() => true;
        public void AddReferences()
        {
            // If an agent has not been assigned, return
            if (ReferencesInputAgent == null)
            {
                LogAdd($"{GetType().FullName} Internal error: Unassigned interface agent - {nameof(ReferencesInputAgent)}", LogVerboseLevel.Error);
                return;
            }

            // Check status
            var unreferenced = CopyModels.Where(x => x.Status == StatusStates.NoRef).ToArray();
            var uncount = unreferenced.Length;

            // Abort if there are no unreferenced tasks to add to
            if (uncount == 0)
            {
                string emsg = "Unable to add more references as there are no unreferenced tasks remaining."
                    + " To add more references, either add more tasks, or clear references from pending tasks.";
                if (AlertDialogAgent != null)
                {
                    AlertDialogAgent.ShowDialog(emsg, "Nothing to reference", AlertLevel.Error);
                }
                LogAdd(emsg, LogVerboseLevel.Error);
                return;
            }

            // If null, user has cancelled adding tasks
            string[]? fileNames = ReferencesInputAgent.GetFiles("Add files to copy names from...");
            if (fileNames == null)
            {
                LogAdd("Cancelled adding tasks", LogVerboseLevel.Debug);
                return;
            }

            // Prepare
            // (Exists validation is not required because only the filename is needed)
            // (Uniqueness validation condition: only for same target folder. Implementation pending)
            var fcount = fileNames.Length;
            int n = 0;

            for (int i = 0; i < fcount; i++)
            {
                if (i >= uncount)
                {
                    break;
                }
                try
                {
                    unreferenced[i].ReferenceFullPath = Path.GetFullPath(fileNames[i]);
                    n++;
                }
                catch (Exception e)
                {
                    LogAdd($"Error - {e.Source}: {e.Message}");
                }
            }

            // Log count mismatch message
            LogAdd($"Added {n} of {fcount} name references."
                + (uncount > fcount ? $" {uncount - fcount} unreferenced tasks remaining. Add more reference files to continue from the next unreferenced task." : "")
                + (uncount < fcount ? $" {fcount - uncount} excess references files were ignored. If this was not intended, clear reference(s) and try again." : "")
                );
        }
        #endregion


        // Commands : Rename
        #region Command : Rename All
        private readonly RenameAllCommand renameAllCommand;
        public RenameAllCommand RenameAllCommand => renameAllCommand;
        public bool CanRenameAll() => true;
        public void RenameAll()
        {
            int n = 0, e = 0;
            foreach (CopyNamingModel model in CopyModels.Where(x => x.Status == StatusStates.Ready))
            {
                if (model.Rename())
                {
                    n++;
                    LogAdd($"Renaming successful: \"{model.OriginalFullPath}\" => \"{model.NewFullPath}\"", LogVerboseLevel.Details);
                }
                else
                {
                    e++;
                    LogAdd($"Renaming failed: \"{model.OriginalFullPath}\" => \"{model.NewFullPath}\".\nReason:\n{model.StatusMessage}", LogVerboseLevel.Error);
                }
            }

            LogAdd($"Files renamed: {n}. There "
                + (e == 1 ? "was" : "were")
                + $" {(e == 0 ? "no" : e)} errors.");
        }
        #endregion


        


        // Initialize
        public ReferencedNamingLogic()
        {
            taskAddCommand = new(this);
            taskRemoveCommand = new(this);
            addReferencesCommand = new(this);
            renameAllCommand = new(this);
        }
        public void OnInterfaceLoaded()
        {
            LogAdd("Program loaded.");
            LogAdd("How-To basics:\n1. Add tasks - Files to be renamed,\n2. Add references - Files to copy names from,\n3. Rename", LogVerboseLevel.Notes);
        }


        // Move entirety of log into a component
        void LogAdd(string message, LogVerboseLevel level = LogVerboseLevel.Information)
        {
            LogEntries.Add(new(message, level));
            LogPurge();
        }
        void LogPurge()
        {
            // Add property bind for max count

            // For count: excess, iterate backwards from n-1 and remove entries
        }

    }
}
