﻿using CopyNamerLib.DialogAgents;
using CopyNamer.Support;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Drawing;
using System.Media;

namespace CopyNamer.Dialogs
{
    /// <summary>
    /// Interaction logic for QueryDialog.xaml
    /// </summary>
    public partial class QueryDialog : Window
    {
        private int result = -1;
        private int cancelIndex = -1;
        private AlertLevel alertLevel = AlertLevel.Information;
        private ImageSource imgSrc { get; set; } = new DrawingImage();

        public QueryDialog()
        {
            InitializeComponent();

            MaxWidth = Math.Round(SystemParameters.MaximizedPrimaryScreenWidth * 0.7, MidpointRounding.ToEven);
            MaxHeight = Math.Round(SystemParameters.MaximizedPrimaryScreenHeight * 0.9, MidpointRounding.ToEven);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var sound = alertLevel switch
            {
                AlertLevel.Query => SystemSounds.Question,
                AlertLevel.Warning => SystemSounds.Exclamation,
                AlertLevel.Error => SystemSounds.Hand,
                AlertLevel.Information => SystemSounds.Asterisk,
                _ => SystemSounds.Asterisk
            };
            sound.Play();
        }

        public int Show(
            string message,
            string title = "",
            string[]? buttons = null,
            AlertLevel level = AlertLevel.Information,
            AlertImage image = AlertImage.Default,
            int defaultButtonIndex = 0,
            int cancelButtonIndex = -1,
            object? customImage = null
            )
        {
            // Apply data
            DialogMessage.Text = message;
            Title = title;

            // Buttons
            ButtonArray.Children.Clear();
            List<Button> Buttons = new();
            if (buttons != null && buttons.Length > 0)
            {
                for(int i = 0; i < buttons.Length; i++)
                {
                    var b = new Button() { Content = buttons[i], Tag = i };
                    Buttons.Add(b);
                    ButtonArray.Children.Add(b);
                }
            }
            else
            {
                var b = new Button() { Content = "OK", Tag = 0, IsDefault = true };
                Buttons.Add(b);
                ButtonArray.Children.Add(b);
            }

            // Dialog Defaults
            Buttons[GetPositiveIndex(defaultButtonIndex, Buttons.Count)].IsDefault = true;
            cancelIndex = GetPositiveIndex(cancelButtonIndex, Buttons.Count);
            if (!Buttons[cancelIndex].IsDefault)
            {
                Buttons[cancelIndex].IsCancel = true;
            }
            else if(Buttons.Count > 1)
            {
                for (int i = Buttons.Count - 1; i >= 0; i--)
                {
                    if (!Buttons[i].IsDefault)
                    {
                        Buttons[i].IsCancel = true;
                        break;
                    }
                }
            }

            // Alert level
            alertLevel = level;


            // Image TODO
            // Assign Path and Fill instead of images.


            // Show the dialog
            ShowDialog();

            // Return response
            return result == -1 ? cancelIndex : result;
        }

        private void DialogResponseClicked(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            result = ButtonArray.Children.IndexOf(button);
            Close();
        }

        // Support
        private static int GetPositiveIndex(int n, int total) => n >= 0 ? Math.Min(n, total - 1) : Math.Max(total + n, 0);
    }
}
