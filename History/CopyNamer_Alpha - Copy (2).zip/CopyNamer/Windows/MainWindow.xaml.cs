﻿using CopyNamer.DialogHandlers;
using CopyNamerLib.Logic;
using CopyNamerLib.Models;
using Microsoft.Win32;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Ribbon;

namespace CopyNamer.Windows
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : RibbonWindow
    {
        readonly ReferencedNamingLogic MyLogic = new();

        // Initialise
        public MainWindow()
        {
            InitializeComponent();
            DataContext = MyLogic;
            MyLogic.TasksInputAgent = new TasksInputHandler();
            MyLogic.ReferencesInputAgent = new ReferencesInputHandler();
            MyLogic.AlertDialogAgent = new MessageBoxHandler();
            MyLogic.QueryDialogAgent = new QueryDialogHandler();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e) => MyLogic.OnInterfaceLoaded();

        // Selection changed update
        private void FileList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            MyLogic.SelectedModels.Clear();
            foreach (var n in FileList.SelectedItems)
            {
                MyLogic.SelectedModels.Add((CopyNamingModel)n);
            }
        }
    }
}
