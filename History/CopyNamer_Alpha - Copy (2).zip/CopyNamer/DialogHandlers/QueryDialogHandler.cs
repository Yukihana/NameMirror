﻿using CopyNamer.Dialogs;
using CopyNamerLib.DialogAgents;

namespace CopyNamer.DialogHandlers
{
    public class QueryDialogHandler : IQueryDialogAgent
    {
        public int ShowDialog(
            string message,
            string title = "",
            string[]? buttons = null,
            AlertLevel level = AlertLevel.Information,
            AlertImage image = AlertImage.Default,
            int defaultButtonIndex = 0,
            int cancelButtonIndex = -1,
            object? customImage = null
            )
        {
            return new QueryDialog().Show(
                message,
                title,
                buttons,
                level,
                image,
                defaultButtonIndex,
                cancelButtonIndex,
                customImage
                );
        }
    }
}