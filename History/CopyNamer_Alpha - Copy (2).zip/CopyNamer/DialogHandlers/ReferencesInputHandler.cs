﻿namespace CopyNamer.DialogHandlers
{
    public class ReferencesInputHandler : OpenFileDialogHandlerBase
    {
        protected override int GetFilterIndex() => 1;
        protected override string GetLastPath() => MyConfig.LastRefsPath;
        protected override void SetLastPath(string path) => MyConfig.LastRefsPath = path;
    }
}
