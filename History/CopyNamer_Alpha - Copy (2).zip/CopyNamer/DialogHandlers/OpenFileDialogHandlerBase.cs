﻿using CopyNamerLib.DialogAgents;
using Microsoft.Win32;
using System.IO;

namespace CopyNamer.DialogHandlers
{
    public abstract class OpenFileDialogHandlerBase : IFilenamesInputAgent
    {
        protected abstract string GetLastPath();
        protected abstract void SetLastPath(string path);
        protected abstract int GetFilterIndex();
        public virtual string[]? GetFiles(string message)
        {
            // Prepare
            OpenFileDialog openFileDialog = new()
            {
                InitialDirectory = GetLastPath(),
                Title = message,
                Filter = MyConfig.FileTypeFilters,
                FilterIndex = GetFilterIndex(),
                Multiselect = true,
                CheckFileExists = true,
                CheckPathExists = true,
                ValidateNames = true,
            };

            //Query User
            if (openFileDialog.ShowDialog() != true)
            {
                return null;
            }

            // Save last path
            if (openFileDialog.FileNames.Length > 0)
                SetLastPath(Path.GetDirectoryName(openFileDialog.FileNames[0]) ?? string.Empty);

            // Deliver data
            return openFileDialog.FileNames;
        }
    }
}
