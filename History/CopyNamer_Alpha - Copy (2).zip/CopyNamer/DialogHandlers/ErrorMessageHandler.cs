﻿using CopyNamer.Support;
using CopyNamerLib.DialogAgents;
using System.Windows;

namespace CopyNamer.DialogHandlers
{
    public class MessageBoxHandler : IAlertDialogAgent
    {
        public void ShowDialog(string message, string title = "Alert", AlertLevel level = AlertLevel.Information)
            => MessageBox.Show(message, title, MessageBoxButton.OK, level.ToWindowsAlertLevel());
    }
}
