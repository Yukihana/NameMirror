﻿namespace CopyNamer.DialogHandlers
{
    public class TasksInputHandler : OpenFileDialogHandlerBase
    {
        protected override int GetFilterIndex() => 0;
        protected override string GetLastPath() => MyConfig.LastTasksPath;
        protected override void SetLastPath(string path) => MyConfig.LastTasksPath = path;
    }
}
