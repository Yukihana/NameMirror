﻿using CopyNamerLib.DialogAgents;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace CopyNamer.Support
{
    public static class Extensions
    {
        public static MessageBoxImage ToWindowsAlertLevel(this AlertLevel alertLevel) => alertLevel switch
        {
            AlertLevel.Information => MessageBoxImage.Information,
            AlertLevel.Query => MessageBoxImage.Question,
            AlertLevel.Warning => MessageBoxImage.Warning,
            AlertLevel.Error => MessageBoxImage.Error,
            _ => MessageBoxImage.Information,
        };

        [DllImport("gdi32.dll", SetLastError = true)]
        private static extern bool DeleteObject(IntPtr hObject);
    }
}