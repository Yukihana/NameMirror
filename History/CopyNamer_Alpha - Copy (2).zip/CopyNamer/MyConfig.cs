﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyNamer
{
    internal static class MyConfig
    {
        /*
        public static string ConfigPath { get; set; }
        public static string ConfigFileName { get; set; }
        */

        // Hardcoded
        public static readonly string FileTypeFilters = "Image files (*.jpg, *.jpeg, *.bmp, *.png, *.gif)|*.JPG;*.JPEG;*.BMP;*.PNG;*.GIF|Document files (*.docx, *.doc, *.pdf, *.rtf)|*.DOCX;*.DOC;*.PDF;*.RTF|All files (*.*)|*.*";

        // Muted
        public static string LastTasksPath { get; set; } = string.Empty;
        public static string LastRefsPath { get; set; } = string.Empty;
    }
}
